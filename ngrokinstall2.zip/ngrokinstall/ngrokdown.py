#!/usr/bin/env python3

from core.color import color
import os
import sys
import requests
import platform
from zipfile import ZipFile

print(color.B +"""
#     #  #####  ######  ####### #    #
#     # #     # #     # #     # #    #
#     # #       #     # #     # #    #
# #   # #       #     # #     # #   #
#  #  # #  #### ######  #     # ###
#   # # #     # #   #   #     # #  #
#    ## #     # #    #  #     # #   #
#     #  #####  #     # ####### #    #
\n""",
color.Y + "Author: Freddy Phoenix Mills\n", 
color.G + "Version: 1.0\n", 
color.R + "E-mail: phoenixgibson007@gmail.com\n" + color.RESET)

completed = color.B + """
                         #####  ####### #     # ######  #       ####### ####### ####### ######  
                        #     # #     # ##   ## #     # #       #          #    #       #     # 
                        #       #     # # # # # #     # #       #          #    #       #     # 
                        #       #     # #  #  # ######  #       #####      #    #####   #     # 
                        #       #     # #     # #       #       #          #    #       #     # 
                        #     # #     # #     # #       #       #          #    #       #     # 
                         #####  ####### #     # #       ####### #######    #    ####### ######  
         """
try:
   requests.get("https://github.com")
except ConnectionError as Error:
   print(color.R + "No internet connection,are you connected?" + color.RESET)
   sys.exit()

linux64 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz"
linux32 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-386.tgz"
linuxarm64 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz"
linuxarm = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm.tgz"
win64 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip"
win32 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-386.zip"
freebsd64 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-freebsd-amd64.tgz"
freebsd32 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-freebsd-386.tgz"
freebsdarm = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-freebsd-arm.tgz"
solaris64 = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-solaris-amd64.tgz"

def linuzdown():
   print(color.G + "You are on a linux OS" + color.RESET)
   print(color.G + "[*] Checking if there is an existing ngrok Tarball and removing if there is one" + color.RESET)
   os.system("sleep 1")
   if os.path.isfile("/tmp/ngrok.tgz"):
      os.system("rm /tmp/ngrok.tgz")
   else:
      print(color.G + "[*] No existing Tarball found,Download will continue")

   os.system("uname -m")
   print(color.B + """
   1.) Linux 33bit(i386/x86)
   2.) Linux 64bit(amd64/x86_64)
   3.) Linux arm 32bit(armv71)
   4.) Linux arm 64bit(arm64)""" + color.RESET)
   optnum = int(input(color.G + "What is your Architecture >>> " + color.RESET))
   if optnum == 1:
          print(color.G + "[*] Starting Ngrok download for Linux i386" + color.RESET)
          os.system("curl https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-386.tgz --output /tmp/ngrok.tgz")
          os.system("tar -xf /tmp/ngrok.tgz -C /usr/local/bin && chmod +x /usr/local/bin/ngrok")
   elif optnum == 2:
          print(color.G + "[*] Starting Ngrok download for Linux Amd64" + color.RESET)
          os.system("curl https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz --output /tmp/ngrok.tgz")
          os.system("tar -xf /tmp/ngrok.tgz -C /usr/local/bin/ && chmod +x /usr/local/bin/ngrok")
   elif optnum == 3:
          print(color.G + "[*] Starting Ngrok download for Linux Arm" + color.RESET)
          os.system("curl https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm.tgz --output /tmp/ngrok.tgz")
          os.system("tar -xf /tmp/ngrok.tgz -C /usr/local/bin && chmod +x /usr/local/bin/ngrok")
   elif optnum == 4:
          print(color.G + "[*] Starting Ngrok download for Arm64" + color.RESET)
          os.system("curl https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-arm64.tgz --output /tmp/ngrok.tgz")
          os.system("tar -xf /tmp/ngrok.tgz -C /usr/local/bin/ && chmod +x /usr/local/bin/ngrok")

def windown():
   print(color.G + "[*] You are on a Windows OS" + color.RESET)
   print(color.G + "[*] Checking if there is an existing ngrok Tarball and removing if there is one" + color.RESET)
   os.system("sleep 1")
   if os.path.isfile("ngrok-v3-stable-windows-386.zip"):
      os.system("del ngrok-v3-stable-windows-386.zip")
   if os.path.isfile("ngrok-v3-stable-windows-amd64.zip"):
      os.system("del ngrok-v3-stable-windows-amd64.zip")
   else:
      print(color.G + "[*] No existing Tarball found,Download will continue")

   print(color.G + "[*] Is your installation 32bit or 64bit?  Choose from the below options" + color.RESET)
   print(color.B + """
   1.)32 bit(i386)
   2.)64 bit(amd64) """ + color.RESET)
   winoptnum = input(color.G + "Choose from the above arch" + color.RESET)
   if winoptnum == 1:
      os.system("wget.exe https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-386.zip")
      with ZipFile("ngrok-v3-stable-windows-386.zip", "r") as file:
         file.extractall()
         file.close()
   elif winoptnum == 2:
      os.system("wget.exe https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip")
      with ZipFile("ngrok-v3-stable-windows-amd64.zip", "r") as file:
         file.extractall()
         file.close()


if platform.system() == "Linux":
   linuzdown()
   print(completed)
elif platform.system() == "Windows":
   windown()
   print(completed)
#elif platform.system() == "Darwin":
#  darwindown()
