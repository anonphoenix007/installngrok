#!/usr/bin/env python3

from colorama import Fore

class color():
    R = Fore.RED
    G = Fore.GREEN
    B = Fore.BLUE
    Y = Fore.YELLOW
    RESET = Fore.RESET

def banner():
    print(color.R + """
    #######                  #####
    #       # #      ###### #     # ###### #####  #    #
    #       # #      #      #       #      #    # #    #
    #####   # #      #####   #####  #####  #    # #    #
    #       # #      #            # #      #####  #    #
    #       # #      #      #     # #      #   #   #  #
    #       # ###### ######  #####  ###### #    #   ## 
    """ + color.RESET)
